/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ticketconcert;
import java.util.Scanner;

/**
 *
 * @author ASUS
 */
public class Ticketconcertmenu {
    private String[] Accout_Name = {};
    private boolean[] Ticket_Status = {};
    private int[] Ticket_price = {};
    private int[] statusseat = {10, 10, 10, 10, 10, 10, 10, 10}; //บอกจำนวนที่นั่งของแต่ละ zone

    public Ticketconcertmenu() {
    }
    
    public void Ticketmenu(){
        Scanner input = new Scanner(System.in);
            System.out.println("==Welcome to Concert's Ticket==");
            System.out.print("1. Seat and Price \n");
            System.out.print("2. Day and time \n");
            System.out.print("3. Buy Ticket \n");
            System.out.print("4. Check Status \n");
            System.out.print("\n==Enter Your Menu Choice : ");
            int menu = input.nextInt();
            switch(menu) {
                case 1: 
                    System.out.println("[Seat and Price]");
                    System.out.print(Ticketconcert.getSeatAndPrice());
                    Ticketmenu();
                    break;
                case 2:
                    System.out.println("[Day and Time]");
                    System.out.print(Ticketconcert.getDayAndTime());
                    Ticketmenu();
                    break;
                case 3:
                    System.out.println("[Buy Ticket]");
                    Scanner account = new Scanner(System.in);
                    
                    System.out.print("Acoount Name : ");
                    String accountName = account.nextLine();  
                    
                    
                    Ticketconcert tk = new Ticketconcert();
                    Ticketconcert pt = new Ticketconcert(accountName);
                    System.out.println("Your Zone is : " + tk.buyTicket() + " " + "Price Ticket : " + pt.priceticket()) ;
                    
               
                    Ticketconcert dd = new Ticketconcert(accountName);
                    Ticketconcert tt = new Ticketconcert(accountName);
                    System.out.print("Your day is : " + dd.dateandtime() + " " + "Your Time's Concert is : " + tt.timeconcert());
                    
                    
                    break;
                case 4:
                    System.out.println("[Check Status]");
                    
                    break;
                default:
                    Ticketmenu();
                    break;
            }
        }
//            while (true) {
//                 System.out.println("==Welcome to Concert's Ticket==");
//                 System.out.println("1. Seat and Price \n");
//                 System.out.println("2. Day and time \n");
//                 System.out.println("3. Buy Ticket \n");
//                 System.out.println("4. Check Status \n");
//                 System.out.println("\n==Enter Your Menu Choice : ");
//                 
//            int select_menu = input.nextInt();
//            Ticketconcert tk = new Ticketconcert("test")
//            switch (select_menu) {
//                
//                case 1 : 
//                    
//            }
//            }
            
    /*public void HowmanyTicket() {
        Scanner input = new Scanner(System.in);
        
            System.out.println("How many Concert Ticket?");
            int amount = input.nextInt();
            if(amount < 1) {
                amount = 1;
            }
            Accout_Name = new String[amount];
            Ticket_Status = new boolean[amount];
            Ticket_price = new int[amount];
            for (int i = 0; i<= amount-1; i++){
                int num = i+1;
                
            }*/

    
    
            
           
    }




