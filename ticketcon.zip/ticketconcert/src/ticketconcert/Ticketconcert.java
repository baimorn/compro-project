/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ticketconcert;

import java.util.Scanner;

/**
 *
 * @author ASUS
 */
public class Ticketconcert {
    
    //class แรก เป็นการประกาศชื่อตัวแปรทั้งหมด
    private String accoutname; //บอกคือผู้ใช้ที่เข้ามาซื้อ
    private static final String[] seat = {"A1", "A2", "B1", "B2", "C1", "C2", "D1", "D2"}; //zone ที่นั่ง
    private static final String[] day = {"Saturday","Sunday"}; //บอกวันที่จัดงาน
    private static final String[] time = {"12:00","17:00"}; //บอกเวลของการจัดงาน
    private static final String[] price = {"5000", "5000", "4000", "4000", "3000", "3000", "2000", "2000"}; //บอกราคาของแต่ละบัตร
    private static int zone;
//    private boolean statusticket;
    Scanner sc = new Scanner(System.in);
    
    public String buyTicket() {
//    Scanner zone = new Scanner(System.in);
    System.out.print("Choose Number of zone : ");
    zone = sc.nextInt();
    switch(zone){
        case 1:
            return seat[0]; 
            
        case 2:
            return seat[1];
            
        case 3:
            return seat[2];
            
        case 4:
            return seat[3];
        
        case 5:
            return seat[4];
        
        case 6:
            return seat[5];
          
        case 7:
            return seat[6];
         
        case 8:
            return seat[7];
        }
    return "Don't have this zone !!!" ;
    }
    
    public String priceticket() {
        //Scanner priceticket = new Scanner(System.in);
        
        switch(zone) {
            case 1:
                return price[0];
            
            case 2:
                return price[1];
            
            case 3:
                return price[2];
            
            case 4:
                return price[3];
            
            case 5:
                return price[4];
            
            case 6:
                return price[5];
            
            case 7:
                return price[6];
            
            case 8:
                return price[7];
        }
        return null ;
    }
    
    public String dateandtime(){
        //Scanner dd = new Scanner(System.in);
        System.out.print("Choose Number of date and time : ");
        switch(sc.nextInt()){
            case 1:
                return day[0];
                
            case 2:
                return day[1];
        }
        return "Don't have concert this day !!!" ;
    }
    
    public String timeconcert(){
        System.out.print("Choose Number of Time's Concert : ");
        switch(sc.nextInt()){
            case 1:
                return time[0];
            
            case 2:
                return time[1];
        }
        return "Concert don't have this time. !!!";
    }
    public Ticketconcert(){
        
    }
    public Ticketconcert(String accoutname){
        this.accoutname = accoutname ;
    }

    public String getAccoutname() {
        return accoutname;
    }
    public String seat(int i){
        if(i>seat.length-1||i<0){return "Don't have this zone";}
        return seat[i-1];
        
    }
    
    public static String getSeatAndPrice(){
        StringBuilder str = new StringBuilder();
        for (int i = 0; i < seat.length; i++) {
            str.append("ID: "+ (i+1) + " |Seat : " + seat[i]+"| Price : "+ price[i]+"\n");
        }
        return str.toString();
    }
    
    public String[] getSeat() {
        return seat;
    }

    public String[] getDay() {
        return day;
    }

    public String[] getTime() {
        return time;
    }
    public static String getDayAndTime() {
        StringBuilder dt = new StringBuilder();
        for (int j = 0; j < day.length; j++) {
            dt.append("ID: "+ (j+1) +" |Day : "+day[j] + "| Time : "+time[j]+"\n");
        }
        return dt.toString();
    }   
    public String[] getPrice() {
        return price;
    }
    @Override
    public String toString() {
        return "Ticketconcert{" + "accoutname=" + accoutname + ", seat=" + seat + ", day=" + day + ", time=" + time + ", price=" + price + ", sc=" + sc + '}';
    }
    
    
}









    /*public String day(int j){
        if(j>day.length-1||j<0){return "Don't have this day";}
        return day[j-1];
    }
    public String time(int k){
        if(k>time.length-1||k<0){return "Don't have this time";}
        return time[k-1];
    }
    public int price(int l){
        if(l>price.length-1||l<0){return 0;}
        return price[l-1];
    }
   
   public static String buyTicket(String accountName) {
        return accountName;
   }*/
    

    
    //    public int statusseat(int m){
//        if(1>statusseat.length-1||m>=0){} else {
//            return 0;
//        }
//        return statusseat[m-1];
//    }
//    public boolean statusticket(){
//        return this.statusticket = statusticket ;
//    }

//    @Override
//    public String toString() {
//        return "Ticketconcert{" + "accoutname=" + accoutname + ", seat=" + seat + ", day=" + day + ", time=" + time + ", price=" + price + ", zone=" + statusseat + ", status=" + statusticket + ", sc=" + sc + '}';
//    }
//

